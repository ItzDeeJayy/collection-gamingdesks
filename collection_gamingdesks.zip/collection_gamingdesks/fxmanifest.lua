-- FX Information --
fx_version   'cerulean'
lua54        'yes'
game         'gta5'

-- Resource Information --
name         'Collection Gaming Desks Bundle Pack'
version      '1.0.0'
author       'DJ'
description  'Bundle Pack of Gaming Desks Bundle Pack'

-- Manifest --
dependencies {
    '/server:5181',
    '/onesync'
  }

data_file 'DLC_ITYP_REQUEST' 'stream/props.ytyp'

dependency '/assetpacks'